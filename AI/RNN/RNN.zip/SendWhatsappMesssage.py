import pywhatkit
# Send a message at a specific time (HH, MM in 24-hr format)
pywhatkit.sendwhatmsg('+919032842466', 'Hello from Python!', 20, 6)
